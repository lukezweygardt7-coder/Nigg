#!/usr/bin/env sh
set -eu
printf '%s\n' 'Rose Companion - Forge 1.12.2 build'
printf '%s\n' 'Requires a Java 8 JDK and Gradle 7.6.4.'
java -version
gradle --version
gradle clean build --no-daemon --stacktrace
printf '%s\n' 'Build output: build/libs/RoseCompanion-1.0.0.jar'
