package com.rosecompanion.client;

import com.rosecompanion.ai.RoseAIService;
import com.rosecompanion.ai.RoseConfig;
import com.rosecompanion.ai.VoiceRecorder;
import com.rosecompanion.ai.WorldSnapshot;
import com.rosecompanion.network.RoseActionMessage;
import com.rosecompanion.network.RoseNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

import java.io.File;

public class RoseClientEvents {
    private static final KeyBinding VOICE_KEY = new KeyBinding(
            "key.rose.voice", Keyboard.KEY_V, "key.categories.rosecompanion");
    private static VoiceRecorder recorder;

    public static void registerKey() {
        ClientRegistry.registerKeyBinding(VOICE_KEY);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (!VOICE_KEY.isPressed()) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (recorder == null) {
            if (RoseConfig.ASSEMBLYAI_API_KEY == null || RoseConfig.ASSEMBLYAI_API_KEY.trim().isEmpty()
                    || RoseConfig.GEMINI_API_KEY == null || RoseConfig.GEMINI_API_KEY.trim().isEmpty()) {
                chat("Add both API keys to config/rosecompanion.properties before using voice chat.");
                return;
            }
            try {
                recorder = new VoiceRecorder(RoseConfig.VOICE_MAX_SECONDS);
                recorder.start();
                chat("Microphone ON. Talk now, then press V again to send your message.");
            } catch (Exception ex) {
                recorder = null;
                chat("I couldn't open your microphone. Check your microphone permissions and input device.");
            }
        } else {
            final VoiceRecorder finished = recorder;
            recorder = null;
            finished.stop();
            final String snapshot = WorldSnapshot.capture(mc.world, mc.player);
            chat("Microphone OFF. I'm listening to your message now...");
            Thread worker = new Thread(() -> {
                File wav = null;
                try {
                    wav = finished.writeWav();
                    RoseAIService.processRecording(wav, snapshot);
                } catch (Exception ex) {
                    if (wav != null && wav.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        wav.delete();
                    }
                    chat("I couldn't read that recording. Try again.");
                }
            }, "Rose-AI-Voice-Request");
            worker.setDaemon(true);
            worker.start();
        }
    }

    public static void sendIntent(String action, String item, String response) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.getConnection() == null) {
            chat("Join a world before asking me to do things.");
            return;
        }
        RoseNetwork.CHANNEL.sendToServer(new RoseActionMessage(action, item, response));
    }

    public static void chat(String text) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null) return;
        mc.addScheduledTask(() -> {
            if (mc.player != null) {
                String safe = text == null ? "Woof!" : text.replace('\n', ' ').replace('\r', ' ');
                if (safe.length() > 220) safe = safe.substring(0, 217) + "...";
                mc.player.sendMessage(new TextComponentString("§dRose: §f" + safe));
            }
        });
    }
}
