package com.rosecompanion.item;

import com.rosecompanion.RoseCompanion;
import com.rosecompanion.entity.EntityRoseDog;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemRoseWhistle extends Item {
    public ItemRoseWhistle() {
        setRegistryName(RoseCompanion.MODID, "rose_whistle");
        setTranslationKey(RoseCompanion.MODID + ".rose_whistle");
        setCreativeTab(CreativeTabs.MISC);
        setMaxStackSize(1);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack held = player.getHeldItem(hand);
        if (!world.isRemote) {
            EntityRoseDog existing = EntityRoseDog.findOwnedDog(world, player, 48.0D);
            if (existing == null) {
                EntityRoseDog rose = new EntityRoseDog(world);
                Vec3d look = player.getLookVec();
                rose.setPosition(player.posX + look.x * 1.5D, player.posY, player.posZ + look.z * 1.5D);
                rose.setTamed(true);
                rose.setOwnerId(player.getUniqueID());
                rose.setCustomNameTag("Rose");
                rose.setAlwaysRenderNameTag(true);
                rose.enablePersistence();
                world.spawnEntity(rose);
                player.sendMessage(new net.minecraft.util.text.TextComponentString("§dRose: §fI'm here, Sophie!"));
            } else {
                existing.setSitting(false);
                player.sendMessage(new net.minecraft.util.text.TextComponentString("§dRose: §fI'm already right here!"));
            }
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, held);
    }
}
