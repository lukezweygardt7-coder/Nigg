package com.rosecompanion.network;

import com.rosecompanion.RoseCompanion;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public final class RoseNetwork {
    public static final SimpleNetworkWrapper CHANNEL =
            NetworkRegistry.INSTANCE.newSimpleChannel(RoseCompanion.MODID);
    private static boolean initialized;

    private RoseNetwork() {
    }

    public static synchronized void init() {
        if (initialized) return;
        CHANNEL.registerMessage(RoseActionMessage.Handler.class, RoseActionMessage.class, 0, Side.SERVER);
        initialized = true;
    }
}
