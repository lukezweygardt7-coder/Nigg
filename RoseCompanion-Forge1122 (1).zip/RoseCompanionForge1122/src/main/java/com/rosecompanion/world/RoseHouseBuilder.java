package com.rosecompanion.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public final class RoseHouseBuilder {
    private RoseHouseBuilder() {
    }

    public static boolean buildStarterHouse(World world, EntityPlayerMP player) {
        EnumFacing forward = EnumFacing.fromAngle(player.rotationYaw);
        EnumFacing side = forward.rotateY();
        int centerX = player.getPosition().getX() + forward.getXOffset() * 4;
        int centerZ = player.getPosition().getZ() + forward.getZOffset() * 4;
        BlockPos center = new BlockPos(centerX, 0, centerZ);
        // Use the top surface block as the floor layer so the entrance is level with the ground.
        int baseY = world.getHeight(center).getY() - 1;

        // Keep the build to a flat, soft-surface 5 x 5 footprint and never overwrite structures.
        for (int s = -2; s <= 2; s++) {
            for (int f = -2; f <= 2; f++) {
                int x = centerX + side.getXOffset() * s + forward.getXOffset() * f;
                int z = centerZ + side.getZOffset() * s + forward.getZOffset() * f;
                BlockPos column = new BlockPos(x, 0, z);
                BlockPos ground = world.getHeight(column).down();
                if (!world.isBlockLoaded(ground) || ground.getY() != baseY) return false;
                Block surface = world.getBlockState(ground).getBlock();
                if (surface != Blocks.GRASS && surface != Blocks.DIRT
                        && surface != Blocks.SAND && surface != Blocks.GRAVEL) return false;
                for (int y = baseY + 1; y <= baseY + 4; y++) {
                    BlockPos check = new BlockPos(x, y, z);
                    if (!world.isBlockLoaded(check)) return false;
                    if (!world.getBlockState(check).getBlock().isReplaceable(world, check)) return false;
                }
            }
        }

        IBlockState planks = Blocks.PLANKS.getDefaultState()
                .withProperty(BlockPlanks.VARIANT, BlockPlanks.EnumType.OAK);
        IBlockState glass = Blocks.GLASS.getDefaultState();

        // 5 x 5 floor.
        for (int s = -2; s <= 2; s++) {
            for (int f = -2; f <= 2; f++) {
                set(world, at(centerX, baseY, centerZ, side, forward, s, f), planks);
            }
        }

        // Three-block-high perimeter walls; the front center is left open for a door.
        for (int height = 1; height <= 3; height++) {
            for (int s = -2; s <= 2; s++) {
                for (int f = -2; f <= 2; f++) {
                    boolean edge = Math.abs(s) == 2 || Math.abs(f) == 2;
                    if (!edge) continue;
                    if (f == -2 && s == 0 && height <= 2) continue;
                    BlockPos pos = at(centerX, baseY + height, centerZ, side, forward, s, f);
                    set(world, pos, planks);
                }
            }
        }

        // Little glass windows.
        set(world, at(centerX, baseY + 2, centerZ, side, forward, -2, 0), glass);
        set(world, at(centerX, baseY + 2, centerZ, side, forward, 2, 0), glass);
        set(world, at(centerX, baseY + 2, centerZ, side, forward, 0, -2), glass);

        // Simple wooden door facing outward from the front wall.
        BlockPos doorPos = at(centerX, baseY + 1, centerZ, side, forward, 0, -2);
        IBlockState door = Blocks.OAK_DOOR.getDefaultState()
                .withProperty(BlockDoor.FACING, forward.getOpposite())
                .withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.LOWER);
        set(world, doorPos, door);
        set(world, doorPos.up(), door.withProperty(BlockDoor.HALF, BlockDoor.EnumDoorHalf.UPPER));

        // Flat wooden roof.
        for (int s = -2; s <= 2; s++) {
            for (int f = -2; f <= 2; f++) {
                set(world, at(centerX, baseY + 4, centerZ, side, forward, s, f), planks);
            }
        }
        return true;
    }

    private static BlockPos at(int cx, int y, int cz, EnumFacing side, EnumFacing forward, int s, int f) {
        return new BlockPos(cx + side.getXOffset() * s + forward.getXOffset() * f,
                y, cz + side.getZOffset() * s + forward.getZOffset() * f);
    }

    private static void set(World world, BlockPos pos, IBlockState state) {
        world.setBlockState(pos, state, 3);
    }
}
