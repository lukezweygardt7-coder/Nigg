package com.rosecompanion.ai;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.TargetDataLine;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

/** Captures a local microphone recording until the player presses V again. */
public class VoiceRecorder {
    private static final AudioFormat FORMAT = new AudioFormat(16000.0F, 16, 1, true, false);
    private final int maxBytes;

    private final AtomicBoolean recording = new AtomicBoolean(false);
    private final ByteArrayOutputStream audio = new ByteArrayOutputStream();
    private TargetDataLine line;
    private Thread captureThread;
    private volatile File outputFile;
    private volatile Exception failure;

    public VoiceRecorder(int maxSeconds) {
        this.maxBytes = 16000 * 2 * Math.max(10, Math.min(300, maxSeconds));
    }

    public void start() throws Exception {
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
        line = (TargetDataLine) AudioSystem.getLine(info);
        line.open(FORMAT);
        line.start();
        recording.set(true);
        captureThread = new Thread(this::capture, "Rose-Microphone-Capture");
        captureThread.setDaemon(true);
        captureThread.start();
    }

    private void capture() {
        byte[] buffer = new byte[4096];
        try {
            while (recording.get()) {
                int count = line.read(buffer, 0, buffer.length);
                if (count > 0) {
                    synchronized (audio) {
                        int allowed = Math.min(count, maxBytes - audio.size());
                        if (allowed > 0) {
                            audio.write(buffer, 0, allowed);
                        }
                        if (audio.size() >= maxBytes) {
                            recording.set(false);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            if (recording.get()) {
                failure = ex;
            }
        }
    }

    public void stop() {
        recording.set(false);
        if (line != null) {
            try {
                line.stop();
            } catch (Exception ignored) {
            }
            try {
                line.close();
            } catch (Exception ignored) {
            }
        }
    }

    public File writeWav() throws Exception {
        if (captureThread != null) {
            captureThread.join(5000L);
        }
        if (failure != null) {
            throw failure;
        }
        byte[] data;
        synchronized (audio) {
            data = audio.toByteArray();
        }
        if (data.length < 1200) {
            throw new IllegalStateException("The microphone recording was too short or empty.");
        }
        File wav = File.createTempFile("rose-voice-", ".wav");
        long frames = data.length / FORMAT.getFrameSize();
        try (AudioInputStream input = new AudioInputStream(new ByteArrayInputStream(data), FORMAT, frames)) {
            AudioSystem.write(input, AudioFileFormat.Type.WAVE, wav);
        }
        outputFile = wav;
        return wav;
    }

    public File getOutputFile() {
        return outputFile;
    }
}
