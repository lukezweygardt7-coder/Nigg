package com.rosecompanion.ai;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.LinkedHashMap;
import java.util.Map;

/** Small, bounded sensor snapshot. It is captured on the Minecraft thread and sent as text. */
public final class WorldSnapshot {
    private WorldSnapshot() {
    }

    public static String capture(World world, EntityPlayer player) {
        if (world == null || player == null) {
            return "World information unavailable.";
        }

        Map<String, Integer> counts = new LinkedHashMap<>();
        int radius = 6;
        int minY = Math.max(1, player.getPosition().getY() - 3);
        int maxY = Math.min(world.getHeight() - 2, player.getPosition().getY() + 4);
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();

        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                for (int y = minY; y <= maxY; y++) {
                    cursor.setPos(player.getPosition().getX() + x, y, player.getPosition().getZ() + z);
                    if (!world.isBlockLoaded(cursor)) {
                        continue;
                    }
                    IBlockState state = world.getBlockState(cursor);
                    ResourceLocation id = state.getBlock().getRegistryName();
                    if (id == null) {
                        continue;
                    }
                    String name = id.toString();
                    if (name.endsWith("_ore") || name.equals("minecraft:grass")
                            || name.equals("minecraft:dirt") || name.equals("minecraft:sand")
                            || name.equals("minecraft:gravel") || name.equals("minecraft:water")
                            || name.equals("minecraft:lava") || name.equals("minecraft:log")
                            || name.equals("minecraft:log2")) {
                        counts.put(name, counts.containsKey(name) ? counts.get(name) + 1 : 1);
                    }
                }
            }
        }

        StringBuilder nearby = new StringBuilder();
        int listed = 0;
        for (Entity entity : world.loadedEntityList) {
            if (entity == player || entity.isDead || entity.getDistance(player) > 10.0F) {
                continue;
            }
            if (listed++ >= 8) {
                break;
            }
            if (nearby.length() > 0) {
                nearby.append(", ");
            }
            nearby.append(entity.getName()).append(" (")
                    .append(Math.round(entity.getDistance(player))).append(" blocks)");
        }

        String biome = world.getBiome(player.getPosition()).getBiomeName();
        return "Player position=" + player.getPosition().getX() + "," + player.getPosition().getY()
                + "," + player.getPosition().getZ()
                + "; biome=" + biome
                + "; nearby blocks=" + counts
                + "; nearby entities=" + (nearby.length() == 0 ? "none" : nearby)
                + ". Only this small loaded area was inspected; unseen terrain is unknown.";
    }
}
